import Auth from "./pages/Auth";


function App() {
  return <Auth />;
}

export default App;
